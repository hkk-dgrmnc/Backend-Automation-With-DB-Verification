import dotenv from 'dotenv';

dotenv.config();

const requestTimeoutMs = Number(process.env.REQUEST_TIMEOUT_MS ?? 30000);

export const env = {
  baseUrl: process.env.BASE_URL ?? 'https://fakestoreapi.com',
  requestTimeoutMs,
  isCi: process.env.CI === 'true' || process.env.CI === '1',
  auth: {
    username: process.env.AUTH_USERNAME,
    password: process.env.AUTH_PASSWORD
  }
};
