import dotenv from 'dotenv';
import type { PoolConfig } from 'pg';

dotenv.config();

const dbPort = process.env.DB_PORT ? Number(process.env.DB_PORT) : undefined;
const poolMax = process.env.DB_POOL_MAX ? Number(process.env.DB_POOL_MAX) : undefined;

export const dbConfig: PoolConfig = {
  host: process.env.DB_HOST,
  port: dbPort,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  max: poolMax,
  ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : undefined
};
