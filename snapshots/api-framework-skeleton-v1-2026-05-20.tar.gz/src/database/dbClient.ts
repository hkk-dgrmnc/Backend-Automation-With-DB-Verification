import { Pool } from 'pg';
import { dbConfig } from '../config/dbConfig';

const pool = new Pool(dbConfig);

export async function query(text: string, params: unknown[] = []) {
  const result = await pool.query(text, params);
  return result.rows;
}

export async function closeDbPool() {
  await pool.end();
}
